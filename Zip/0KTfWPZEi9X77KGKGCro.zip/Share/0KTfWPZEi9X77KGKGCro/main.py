WIDTH = 390
HEIGHT = 390
import random

print(random.randint(1,5))#2