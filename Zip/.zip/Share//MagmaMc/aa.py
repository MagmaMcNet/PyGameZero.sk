def hello():
	print("a")