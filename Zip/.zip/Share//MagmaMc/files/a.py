print("lol")
