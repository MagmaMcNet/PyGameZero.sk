var $builtinmodule = function (name) {
mod={}
return mod;
};