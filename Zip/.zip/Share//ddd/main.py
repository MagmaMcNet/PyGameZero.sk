# imported custom modules http://magma-mc.net/Share/MagmaMc_Clicker1/files/
from random import randint
import filez
import json

WIDTH = 1280
HEIGHT = 720
FPS = 30

mode = "Menu"
dev = False


title = Actor("title", center=(WIDTH/2, 325), anchor=('center', 'center'))
# Buttons
x_button = Actor("redbox", center=(1250, 30))
play_button = Actor("Play_Button", center=(WIDTH/2, 400))
shop_button = Actor("Shop_Button", center=(WIDTH/2, 450))
skins_button = Actor("Skins_Button", center=(WIDTH/2, 500))
red_button1 = Actor("red_button", center=(1140, 2*70))
red_button2 = Actor("red_button", center=(1140, 3*70))
red_button3 = Actor("red_button", center=(1140, 4*70))
red_button4 = Actor("red_button", center=(1140, 5*70))
red_button5 = Actor("red_button", center=(1140, 6*70))
yellow_button1 = Actor("yellow_button", center=(1140, 7*70))
# Images
player = Actor("Skin1", center=(300, HEIGHT/2))
Smoke = []
print("a")
for num in range(1,8):
    actor = Actor("Smoke_0"+str(num), pos=(-200, -200))
    actor._orig_surf = pygame.transform.scale(actor._orig_surf, (50, 50))
    actor._update_pos()
    Recolor(actor._orig_surf, (randint(50, 300), randint(10, 150), randint(10, 150)))
    Smoke.append(actor)

# Change Image Scale
player._orig_surf = pygame.transform.scale(player._orig_surf, (300, 300))
title._orig_surf = pygame.transform.scale(title._orig_surf, (600, 80))
red_button1._orig_surf = pygame.transform.scale(red_button1._orig_surf, (250, 64))
red_button2._orig_surf = pygame.transform.scale(red_button2._orig_surf, (250, 64))
red_button3._orig_surf = pygame.transform.scale(red_button3._orig_surf, (250, 64))
red_button4._orig_surf = pygame.transform.scale(red_button4._orig_surf, (250, 64))
red_button5._orig_surf = pygame.transform.scale(red_button5._orig_surf, (250, 64))
yellow_button1._orig_surf = pygame.transform.scale(yellow_button1._orig_surf, (250, 64))

player._update_pos()
title._update_pos()
red_button1._update_pos()
red_button2._update_pos()
red_button3._update_pos()
red_button4._update_pos()
red_button5._update_pos()
yellow_button1._update_pos()
# Save The Players Data

class PlayerData:
    def SAVE():
        filez.fwrite('/Saves/'+str(Cookies.get("UserID"))+'.json', json.dumps(save, sort_keys=True, indent=4), "c")
    def GET():
        return str(filez.fread('/Saves/'+str(Cookies.get("UserID"))+'.json'))


# Player Settings

save = json.loads(PlayerData.GET())
if not key_exists(save, "Coins"):
    save.update({"Coins":"1.0"})
if not key_exists(save, "Upgrade"):
    save.update({"Upgrade":"1.0"})
if not key_exists(save, "Skin"):
    save.update({"Skin":"1.0"})
if not key_exists(save, "Name"):
    name = input("enter name: ")
    save.update({"Name": name})
clock.schedule_interval(PlayerData.SAVE, 1)
def draw():
    screen.clear()
    
    if mode == "Menu":
        play_button.draw()
        shop_button.draw()
        skins_button.draw()
        title.draw()
    elif mode == "Shop":
        screen.draw.text("bsafSDFa", pos=(200,200), fontsize=20)
    elif mode == "Game":
        red_button1.draw()
        red_button2.draw()
        red_button3.draw()
        red_button4.draw()
        red_button5.draw()
        yellow_button1.draw()
        screen.draw.text(str(int(float(save["Upgrade"])*(float(save["Upgrade"]))*50.0)), center=(1140, 6*70-5))
        screen.draw.text("Coins: " + save["Coins"], pos=(5,70), fontsize=50)
        player.draw()
        for particle in Smoke:
            particle.draw()
    if mode != "Menu":
        x_button.draw()
    


def update(dt):
    global mode, save

    if(mode == "Menu"):
        pass

def on_key_up(key):
    global dev, save
    if key == 112:
        a = input("dev password")
        if a == "dev":
            dev = True
    if dev:
        if key == 99:
            save["Coins"] = str(float(input("Coins: ")))
        if key == 120:
            save["Upgrade"] = str(float(input("Upgrade: ")))

def on_mouse_up(button, pos):
    global Smoke
    for smoke in range(0,7):
        Smoke[smoke].pos = (-200, -200)

def on_mouse_down(button, pos):
    global save, upgrade, mode, dev
    
    if player.collidepoint(pos):
        save["Coins"] = str(float(save["Coins"]) + (float(save["Skin"]) * float(save["Upgrade"])))
        smoke_numb = randint(0,6)
        Smoke[smoke_numb].pos = pos
        Sounds.click.play()
    if play_button.collidepoint(pos):
        mode = "Game"
    elif shop_button.collidepoint(pos):
        mode = "Shop"
    elif x_button.collidepoint(pos):
        mode = "Menu"
