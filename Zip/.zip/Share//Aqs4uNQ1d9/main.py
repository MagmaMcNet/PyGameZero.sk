import turtle

#
numb = 250
size = 200
turn = 89

t = turtle.Turtle()
t.shape("turtle")
t.speed(0)


for x in range(0, numb):
    if(x > 200):
        t.color("Red")
    elif(x > 150):
        t.color("Green")
    elif(x > 100):
        t.color("Blue")
    elif(x > 50):
        t.color("black")
    
    t.fd(size)
    t.right(turn)
